var ROMLIST = [
    /*
    {url:"game1.iso",title:"Game1",skipiso:"true",ram:"128"},
    {url:"game2.iso",title:"Game2",skipiso:"true",ram:"128"},
    {url:"game3.iso",title:"Game3",skipiso:"true",ram:"128"},
    */
];
